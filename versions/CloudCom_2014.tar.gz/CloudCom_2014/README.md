oss-community
=============


Qingye Jiang, Young Choon Lee, and Joseph G. Davis<br>
Centre of Parallel and High Performance Computing<br>
School of Information Technologies<br>
The University of Sydney<br>
Sydney NSW 2006, Australia<br>

This project is a work-in-progress paper on the growth, evolution and diversity of open source communities. Part of this work has been submitted to CloudCom 2014 (http://2014.cloudcom.org/). We are currently working on a journal version that covers a large number of open source projects. 

